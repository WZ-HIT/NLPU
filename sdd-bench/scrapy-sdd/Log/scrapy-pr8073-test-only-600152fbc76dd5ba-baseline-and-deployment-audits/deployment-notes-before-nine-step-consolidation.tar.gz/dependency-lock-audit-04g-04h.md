# Scrapy SDD Deployment — Dependency Locks, Steps 04g–04h

## Outcome

Completed dependency locking for cc-sdd 3.0.2 and Spec Kit 1.0.4.
No SDD was initialized or installed into an experiment repository or service.
Only a disposable build virtualenv received the six Spec Kit build dependencies.
Formal runtime execution, skills discovery and Scrapy smoke tests remain pending.

| Component | Result |
| --- | --- |
| cc-sdd | npm lockfile v3; one package entry; no transitive runtime dependencies |
| Spec Kit source | `cb610277fdea781fcfa83d20522c2db37c94068d`; verified by shallow Git fetch |
| Spec Kit runtime | 14 pinned dependencies; 15 entries including the CLI in the final installation lock |
| Spec Kit build | 6 pinned dependencies; `hatchling==1.32.0` |
| Python / uv | 3.11.15 / 0.12.10 |
| Node / npm | 24.20.0 / 11.19.0 |
| Wheel cache | 18 distinct dependency wheels; runtime/build overlap deduplicated |
| Offline build | Passed in a fresh container with `--network=none` |
| Repeat build | Two consecutive builds in the same offline container produced byte-identical wheels |
| Bundled assets | Templates, commands, scripts, extensions, workflows, presets and bundle catalog present |

## Storage and Isolation

Paths below are relative to `scrapy-sdd/environments/sdd-tools/`:

```text
cc-sdd-3.0.2_node-24.20.0_npm-11.19.0_linux-amd64/
├── package.json
└── package-lock.json
speckit-1.0.4_cb610277fdea_py-3.11.15_uv-0.12.10_linux-amd64/
├── build-requirements.in
├── resolve-and-build.sh
├── source.tar.gz
├── build-requirements.txt
├── runtime-requirements.txt
├── install-requirements.txt
├── artifact-manifest.json
├── wheels/                         # 18 downloaded dependency wheels
└── dist/specify_cli-1.0.4-py3-none-any.whl
```

These are reusable build/install inputs, not shared writable runtime state.
The containers used the existing pinned baseline image, UID/GID 1007:1007,
4 CPUs, 8 GiB RAM with no extra swap, 512 PIDs, a read-only root filesystem,
all capabilities dropped, no-new-privileges, and a private 2 GiB `/tmp` tmpfs.
No Scrapy repository, host HOME, credentials or Docker socket was mounted.
Dependency resolution used bridge networking; wheel construction used no network.
Temporary containers and their internal caches were removed after each run.

## Commands and Reproduction Boundaries

The cc-sdd manifest declares only `cc-sdd: 3.0.2`. With the verified Node archive
extracted into a private temporary container, the executed resolver command was:

```bash
npm install --package-lock-only --ignore-scripts --no-audit --no-fund \
  --engine-strict --registry=https://registry.npmjs.org/ --update-notifier=false
```

The manifest was compared byte-for-byte before exporting the lock; no
`node_modules` was created. The lock's package version and npm integrity matched
the official 3.0.2 metadata. Its upstream source commit is
`3795eb4274c07dedcf56c571b5c0a826736f23c8`.

For Spec Kit, `resolve-and-build.sh` preserves the exact in-container commands.
The `resolve` mode fetches the full commit with `--depth=1 --no-tags`, checks HEAD,
the clean worktree and project version, and generates a source archive with Git.
It separately resolves runtime and build locks with hashes, then uses
`pip download --require-hashes --only-binary=:all:` against official PyPI.
The `build` mode creates a private build virtualenv, installs only the locked
build wheels offline, builds twice, compares results, checks bundled assets,
and generates the final installation lock using only the local wheel cache.

Container invocation pattern used for both Spec Kit phases:

```bash
# Set SPEC_DIR to the Spec Kit directory shown above, UV_ARCHIVE to the verified
# common uv archive, and SPEC_STAGE to a dedicated mktemp -d output directory.
# For resolve: PHASE=resolve, NETWORK=bridge.
# For build:   PHASE=build,   NETWORK=none, reusing the successful output directory.
docker run --rm --pull=never --network="$NETWORK" --read-only \
  --user 1007:1007 --cap-drop=ALL --security-opt=no-new-privileges \
  --cpus=4 --memory=8g --memory-swap=8g --pids-limit=512 \
  --tmpfs /tmp:rw,exec,nosuid,nodev,size=2g,mode=1777 \
  --mount "type=bind,src=$UV_ARCHIVE,dst=/inputs/uv.tar.gz,readonly" \
  --mount "type=bind,src=$SPEC_DIR/build-requirements.in,dst=/inputs/build-requirements.in,readonly" \
  --mount "type=bind,src=$SPEC_DIR/resolve-and-build.sh,dst=/inputs/resolve-and-build.sh,readonly" \
  --mount "type=bind,src=$SPEC_STAGE,dst=/output" \
  --workdir /tmp --env HOME=/tmp/home \
  scrapy-sdd-scrapy@sha256:f59cdcb1f1be58c9ee0becf4eff13ea4979aea617aa5bf2c4619ae2c13c4adfa \
  bash /inputs/resolve-and-build.sh "$PHASE"
```

The build invocation did not need the build-requirements.in mount; the generated
build lock was already in `/output`. The fixed timestamp was
`SOURCE_DATE_EPOCH=315532800`, with `PYTHONHASHSEED=0` and `TZ=UTC`.

**Do not re-resolve these locks for a formal experiment.** Re-running `resolve`
against current registries could select different dependency versions. Reuse
the saved locks, source archive and artifacts, verify their hashes, and install
Spec Kit from `install-requirements.txt` with `--require-hashes --no-index
--no-build` into a dedicated per-service virtualenv. Use both local `dist/` and
`wheels/` as find-links locations. Do not synchronize the Scrapy test interpreter.

## Verification and Known Limits

- Every saved artifact was checked against `artifact-manifest.json`.
- Every downloaded wheel hash appeared in the generated dependency locks.
- Runtime dependency versions exactly matched the final installation lock.
- The final Spec Kit wheel SHA256 is
  `6dea3ff784224dde35fd02d265462ddb3c4bfc97d1184127fcc71106a233d880`.
- An initial resolver attempt stopped because uv rejects combining `--no-build`
  with `--only-binary`. The redundant latter flag was removed before the successful
  retry. No dependency installation occurred in the failed attempt.
- npm tarball caching, controlled installations and actual CLI runtime checks
  remain for 04i. This work is not a security vulnerability audit.
- cc-sdd does not declare a Node engine range; compatibility still needs execution.
- Resource enforcement for the three long-running experiment services, runtime
  model/provider/auth/network choices and the final deployment image ID remain pending.

## Official Sources

- [cc-sdd 3.0.2 npm metadata](https://registry.npmjs.org/cc-sdd/3.0.2)
- [cc-sdd fixed source package](https://github.com/gotalab/cc-sdd/blob/3795eb4274c07dedcf56c571b5c0a826736f23c8/tools/cc-sdd/package.json)
- [Spec Kit fixed pyproject](https://github.com/github/spec-kit/blob/cb610277fdea781fcfa83d20522c2db37c94068d/pyproject.toml)
