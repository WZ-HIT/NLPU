# Scrapy SDD Deployment — Offline Installation Verification, Step 04i

## Outcome

All three tools passed locked, offline installation and version/help probes in
separate disposable containers on 2026-09-07. No SDD was initialized. The existing
experiment services and Scrapy repositories were not mounted or modified.

| Tool | Version output | Installed package entries | Offline install | Version/help |
| --- | --- | ---: | --- | --- |
| OpenSpec | `1.12.0` | 80 npm locations | PASS | PASS |
| cc-sdd | `cc-sdd v3.0.2` | 1 npm location | PASS | PASS |
| Spec Kit | `specify 1.0.4` | 15 Python distributions | PASS | PASS |

OpenSpec's 80 install locations use 71 distinct tarballs. cc-sdd uses one tarball.
The 72 downloaded tarballs were checked against each lock's npm integrity value
and additionally recorded with SHA256 and byte size. Files are named by SHA256
under each tool's `npm-artifacts/`; URL mappings are in `artifact-manifest.json`.

## Environment and Isolation

- Image: `scrapy-sdd-scrapy@sha256:f59cdcb1f1be58c9ee0becf4eff13ea4979aea617aa5bf2c4619ae2c13c4adfa`.
- Python 3.11.15, Node 24.20.0 and npm 11.19.0 in all probes; uv 0.12.10 for Spec Kit.
- Each probe used a fresh container, private HOME, private tmpfs and private caches.
- Network disabled, root filesystem read-only, UID/GID 1007:1007, capabilities
  dropped, no-new-privileges, 4 CPUs, 8 GiB RAM/no extra swap, 512 PIDs, 2 GiB tmpfs.
- Only the corresponding tool's inputs, the verifier and common Node/uv archives
  were mounted read-only. The only writable bind mount was its own output directory.
- No host HOME, secrets, Docker socket, Scrapy repo or other SDD directory was mounted.
- Execution was sequential. Containers, installed tools and temporary caches were
  removed on exit; reusable input archives and execution records were retained.

Each probe checked the baseline interpreter before and after installation:
69 packages, `pip check` passed, normalized freeze SHA256 unchanged:

```text
570e1651694fe0e30bbd07a231c2f70cccf09cd18503b8ead34fdfd50f5f3abd
```

Spec Kit was installed into `/tmp/tool-env`, with system-site-packages disabled.
Its 15 distributions passed `uv pip check`; Hatchling was absent from the runtime
environment. The version/help working directory stayed empty for all three tools.

## Executed Installation Strategy

The verifier is stored at `environments/sdd-tools/verify-offline-install.py`.
Final verifier SHA256:
`a9d4c2e32c544f3887e9a59cffbc6e8832f4b117cc7aee10a56a08e34f4ce45d`.

For npm tools, it verifies archive hashes, seeds a fresh private npm cache with
`npm cache add <local-tarball> --offline --ignore-scripts`, copies only the manifest
and lock into `/tmp/npm-tool`, and executes:

```bash
npm ci --offline --ignore-scripts --engine-strict --no-audit --no-fund \
  --registry=https://registry.npmjs.org/
npm ls --all --json
```

It compares both input files after installation and checks each installed package
version against its lock entry. Version/help probes use absolute paths under
`/tmp/npm-tool/node_modules/.bin/`; no npx or global install is involved.

For Spec Kit, it verifies every archived input and uses the fixed uv executable:

```bash
uv venv --python /usr/local/bin/python /tmp/tool-env
uv pip sync /inputs/tool/install-requirements.txt \
  --python /tmp/tool-env/bin/python --offline --no-index \
  --find-links /inputs/tool/dist --find-links /inputs/tool/wheels \
  --require-hashes --no-build
uv pip check --python /tmp/tool-env/bin/python --offline
uv pip list --python /tmp/tool-env/bin/python --format=json --offline
/tmp/tool-env/bin/specify --version
/tmp/tool-env/bin/specify --help
```

The complete subprocess arguments, stdout, stderr and exit codes are retained in:

- [OpenSpec final execution record](offline-install-04i/openspec.json)
- [cc-sdd final execution record](offline-install-04i/cc-sdd.json)
- [Spec Kit final execution record](offline-install-04i/speckit.json)

## Container Command

For each tool, `TOOL_DIR` was set to its versioned directory under
`environments/sdd-tools/`, and `PROBE_OUTPUT` to its own new temporary directory.
`COMMON_DIR` refers to the existing versioned `agent-runtime/.../artifacts/common`.

```bash
docker run --rm --pull=never --network=none --read-only \
  --user 1007:1007 --cap-drop=ALL --security-opt=no-new-privileges \
  --cpus=4 --memory=8g --memory-swap=8g --pids-limit=512 \
  --tmpfs /tmp:rw,exec,nosuid,nodev,size=2g,mode=1777 \
  --mount "type=bind,src=$COMMON_DIR/node-v24.20.0-linux-x64.tar.xz,dst=/inputs/node.tar.xz,readonly" \
  --mount "type=bind,src=$COMMON_DIR/uv-x86_64-unknown-linux-gnu.tar.gz,dst=/inputs/uv.tar.gz,readonly" \
  --mount "type=bind,src=$TOOLS_DIR/verify-offline-install.py,dst=/inputs/probe.py,readonly" \
  --mount "type=bind,src=$TOOL_DIR,dst=/inputs/tool,readonly" \
  --mount "type=bind,src=$PROBE_OUTPUT,dst=/output" \
  --workdir /tmp --env HOME=/tmp/home --env PYTHONDONTWRITEBYTECODE=1 \
  scrapy-sdd-scrapy@sha256:f59cdcb1f1be58c9ee0becf4eff13ea4979aea617aa5bf2c4619ae2c13c4adfa \
  python /inputs/probe.py "$tool"
```

## Retry Record and Limits

The initial cc-sdd installation and version command succeeded, but the verifier
expected an unprefixed version token. Actual output was `cc-sdd v3.0.2`; only the
assertion was corrected. Initial records are retained under
`offline-install-04i/attempts/`. A stale patch-tool path also required refreshing
the patch executable; OpenSpec was run again after the final script was in place.
No tool version, package lock or upstream source was changed to make a probe pass.

This verifies installation, dependency consistency and CLI startup only. It does
not verify initialization, Agent skill discovery, model/provider/auth/network
configuration, security vulnerability status or post-initialization Scrapy tests.
The deployment image has not been built and the three long-running experiment
services still use their baseline environment. Those tasks remain in later steps.
